/**
* Build Scroll Effect
**/

jQuery(document).ready(function() {

  if(jQuery(window).scrollTop() > 622)
    jQuery('.navbar-inverse .navbar-inner').addClass('full');
  else 
    jQuery('.navbar-inverse .navbar-inner').removeClass('full');

  jQuery(window).scroll(function() {

    if(jQuery(window).scrollTop() > 622)
      jQuery('.navbar-inverse .navbar-inner').addClass('full');
    else 
      jQuery('.navbar-inverse .navbar-inner').removeClass('full');

  });

});