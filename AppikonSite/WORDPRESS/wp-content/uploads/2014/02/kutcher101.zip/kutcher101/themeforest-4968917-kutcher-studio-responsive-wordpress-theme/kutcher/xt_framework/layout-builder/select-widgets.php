			<select class="widget_selector">
				<option value="rich_text">Rich Text</option>
				<option value="divider_line">Divider Normal</option>
				<option value="divider_dotted">Divider Dotted</option>
				<option value="divider_shadow">Divider Shadow</option>
				<option value="divider_vertical_line">Divider Vertical Line</option>
				<option value="divider_empty">Empty Space</option>
			</select>