			<select class="widget_selector">
				<optgroup label="1 Column">
					<option value="full">100%</option>
				</optgroup>
				<optgroup label="2 Columns">
					<option value="50_50">50% 50%</option>
					<option value="25_75">25% 75%</option>
					<option value="75_25">75% 25%</option>
					<option value="66_33">66% 33%</option>
					<option value="33_66">33% 66%</option>
					<option value="20_80">20% 80%</option>
					<option value="80_20">80% 20%</option>
				</optgroup>
				<optgroup label="3 Columns">
					<option value="33_33_33">33% 33% 33%</option>
					<option value="25_25_50">25% 25% 50%</option>
					<option value="25_50_25">25% 50% 25%</option>
					<option value="50_25_25">50% 25% 25%</option>
					<option value="20_20_60">20% 20% 60%</option>
					<option value="20_60_20">20% 60% 20%</option>
					<option value="60_20_20">60% 20% 20%</option>
				</optgroup>
				<optgroup label="4 Columns">
					<option value="25_25_25_25">25% 25% 25% 25%</option>
					<option value="20_20_20_40">20% 20% 20% 40%</option>
					<option value="20_20_40_20">20% 20% 40% 20%</option>
					<option value="20_40_20_20">20% 40% 20% 20%</option>
					<option value="40_20_20_20">40% 20% 20% 20%</option>
				</optgroup>
				<optgroup label="5 Columns">
					<option value="20_20_20_20_20">20% 20% 20% 20% 20%</option>
				</optgroup>
				<optgroup label="6 Columns">
					<option value="15_15_15_15_15_15">15% 15% 15% 15% 15% 15%</option>
				</optgroup>
			</select>